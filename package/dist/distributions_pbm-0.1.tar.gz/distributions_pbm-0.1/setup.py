from setuptools import setup

setup(name='distributions_pbm',
      version='0.1',
      description='Binomial and Gaussian distributions',
      packages=['distributions_pbm'],
      author = 'Pablo Bartolomé Molina',
      author_email = 'pablobart.me@gmail.com',
      zip_safe=False)